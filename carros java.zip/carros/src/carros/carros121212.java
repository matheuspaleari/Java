package carros;

import javax.swing.*;
public class carros121212 {
    public static void main(String[] args) {
        int nrodas, nmotores, nbaterias, nescapamento, v,b;
        String r;
        // ESSE MONTE DE ENTRADAS QUE EU FIZ FOI UM TESTE PARA O CARRO1, DARIA PARA REPLICAR PARA OS OUTROS CARROS
        JOptionPane.showMessageDialog(null,"para o primeiro carro insira suas caracteristicas");
        nrodas = Integer.parseInt(JOptionPane.showInputDialog("insira o numero de rodas"));
        nmotores = Integer.parseInt(JOptionPane.showInputDialog("insira o numero de motores(normalmente é 1)"));
        nbaterias = Integer.parseInt(JOptionPane.showInputDialog("insira o numero de baterias ( normalmente é 1)"));
        nescapamento = Integer.parseInt(JOptionPane.showInputDialog("insira o numero de escapamentos (normalmente é 1"));
        v = Integer.parseInt(JOptionPane.showInputDialog("insira a velocidade do carro"));
        carros carro1 = new carros(nrodas, nmotores, nbaterias, nescapamento);
        carro1.velocidade(v);
        r = JOptionPane.showInputDialog("seu carro ira acelerar? [ S / N ]").toLowerCase();
        if(r.equals("s")){
            v = Integer.parseInt(JOptionPane.showInputDialog("quanto seu carro ira acelerar"));
            carro1.velocidade(v);
            JOptionPane.showMessageDialog(null, "a nova velocidade é: "+carro1.velocidade1+" Km/h");
        }else{                    // AK É ONDE A ACELERAÇÃO DO CARRO É CALCULADA
            JOptionPane.showMessageDialog(null, "a velocidade do seu carro ficou inalterada");
        }
        carros carro2 = new carros();
        carros carro3 = new carros(4);
        JOptionPane.showMessageDialog(null,"o primeiro carro tem "+nrodas+" rodas, "+nmotores+" motor, "+nbaterias+" bateria e "+nescapamento+" escapamento");
        System.out.println("essas sao as caracteristicas do primeiro carro: "+carro1);     // PEDIU PARA MOSTRAR TUDO NO CONSOLE, TA AI.
        System.out.println("essas sao as caracteristicas do segundo carro: "+carro2);
        System.out.println("essas sao as caracteristicas do terceiro carro: "+carro3);
    }
}