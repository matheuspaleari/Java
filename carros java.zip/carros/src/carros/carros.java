package carros;

public class carros {
    int nrodas, nmotores, nbaterias, nescapamentos, nvolantes, num, freio, vel;
    int velocidade1 = 0;

    carros(int nrodas, int nmotores, int nbaterias, int nescapamentos, int nvolantes) {
        this.nrodas = nrodas;
        this.nmotores = nmotores;
        this.nbaterias = nbaterias;
        this.nescapamentos = nescapamentos;
        this.nvolantes = nvolantes;
    }
    carros(int nrodas, int nmotores, int nbaterias, int nescapamentos) {
        this.nrodas = nrodas;
        this.nmotores = nmotores;
        this.nbaterias = nbaterias;
        this.nescapamentos = nescapamentos;
    }
    carros(int nrodas, int nmotores, int nbaterias) {
        this.nrodas = nrodas;
        this.nmotores = nmotores;
        this.nbaterias = nbaterias;
    }
    carros(int nrodas, int nmotores) {
        this.nrodas = nrodas;
        this.nmotores = nmotores;
    }
    carros(int nrodas) {
        this.nrodas = nrodas;
    }
    carros() {

    }
    public void freiar(int velocidade,int freio){
        velocidade -= freio;
    }
    public void velocidade(int vel){
        velocidade1 += vel;
    }
    @Override
    public String toString(){
        return this.nrodas+" "+this.nmotores+" "+this.nbaterias+" "+this.nescapamentos+" "+this.nvolantes;
    }

}
